package structure_ABR.arbrebinaire;

public class ExceptionArbreVide extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExceptionArbreVide() {
		super("L'arbre est vide !");
	}
	
}
