
public class ExceptionPréfixeInconnu extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
