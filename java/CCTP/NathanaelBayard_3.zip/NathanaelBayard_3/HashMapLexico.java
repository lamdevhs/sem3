import java.util.HashMap;

public class HashMapLexico extends HashMap<Character, HashMapLexico>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
}
